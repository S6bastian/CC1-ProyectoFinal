#ifndef DOCTOR_H
#define DOCTOR_H
#include "Trabajador.h"
class Doctor:public Trabajador{
public:
	Doctor(std::string,std::string,int,std::string,
		   int,std::string,std::string,
		   std::string, int); 
	void setEspecialidad(std::string);
	void setAniosDeExp(int);
	std::string getEspecialidad();
	int getAniosDeExp();
private:
	std::string especialidad,gradoDeEspecialidad;
	unsigned int aniosDeExp;
};
#endif
