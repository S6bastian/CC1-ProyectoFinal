#ifndef PACIENTE_H
#define PACIENTE_H
#include <string>
#include "Persona.h"
class Paciente:public Persona{
    public:
        Paciente(std::string ,std::string,int ,std::string,
				 int , float , std::string);
        void setPeso(int);
        void setAltura(float nuevaAltura);
        void setEnfermedadC(std::string nuevaEnfemerdadC);
        int getPeso();
        float getAltura();
        std::string getEnfermedadC();
    private:
        int peso;
		float altura;
        std::string enfermedad_c;    
};
#endif
